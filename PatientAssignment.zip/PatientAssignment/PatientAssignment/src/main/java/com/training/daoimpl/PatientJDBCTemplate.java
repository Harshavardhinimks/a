package com.training.daoimpl;
import java.sql.Types;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.training.DAO.PatientsDAO;
import com.training.mapper.PatientMapper;
import com.training.model.Patients;

public class PatientJDBCTemplate implements PatientsDAO {
	
	private HttpServletRequest request;

	
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplateObject;
	   
	   public void setDataSource(DataSource dataSource) {
	      this.dataSource = dataSource;
	      this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	   }

	
	    public void postPatient(@PathVariable("id")int id,@PathVariable("name")String name,@PathVariable("age")int age)
		{
	  
	        try {
	                        int[] types = new int[] {  Types.INTEGER,Types.VARCHAR,Types.INTEGER};
	                        
	                        int i=jdbcTemplateObject.update("insert into PatientMaster(ID,NAME,AGE)  values(?,?,?)", new Object[] {id, name,age },types);
	                        
	                        if(i==1)
	                        {
	                        System.out.println(" INSERT Succesfully");
	                        alert("insert Successfully");
	                        } 
	            }
	        catch (Throwable fault) 
	        {
	                        System.out.println("Got error.  Returning null (404)");
	                        fault.printStackTrace();
	                        
	        }
		}
	   
	    public void updatePatient(@PathVariable("name")String name,@PathVariable("age")int age,@PathVariable("id")int id)
		{
	  
	        try {
	                        int[] types = new int[] {  Types.VARCHAR,Types.INTEGER,Types.INTEGER};
	                        
	                        int i=jdbcTemplateObject.update("update PatientMaster set name = ?, age=? where id=?", new Object[] { name,age,id },types);
	                        
	                        if(i==1)
	                        {
	                        System.out.println(" Update Succesfully");
	                        } 
	            }
	        catch (Throwable fault) 
	        {
	                        System.out.println("Got error.  Returning null (404)");
	                        fault.printStackTrace();
	                        
	        }
		}
	   
	   
	   
	   @RequestMapping(method = RequestMethod.GET)
		public @ResponseBody List<Patients> getAllPatients() {
			
			List<Patients> list=null;
			try {

				list = jdbcTemplateObject.query("select * from PatientMaster",new Object[] { },	new PatientMapper());

				return list;
			} catch (Exception doe) {

				alert("Error output");
				System.out.println(" Null");

				System.out.println(doe.getStackTrace());

				return null;

			}

		}
	 
	   
	   @RequestMapping(method = RequestMethod.GET)
		public @ResponseBody List<Patients> getPatient(	@PathVariable("id") int id,HttpServletRequest request, HttpServletResponse response) {
			
			List<Patients> list=null;
			try {

				list = jdbcTemplateObject.query("select * from PatientMaster where ID=? ",new Object[] { id },new PatientMapper());

				return list;
			} catch (Exception doe) {

				alert("Error output");
				System.out.println("Null");

				System.out.println(doe.getStackTrace());

				return null;

			}

		}
	   
	   
	   public void deletePatient(@PathVariable("id")int id)
		{
	  
	        try {
	                        int[] types = new int[] {Types.INTEGER};
	                        
	                        int i=jdbcTemplateObject.update("delete from PatientMaster where ID=?", new Object[] {id },types);
	                        
	                        if(i==1)
	                        {
	                        System.out.println(" Delete Succesfully");
	                        } 
	            }
	        catch (Throwable fault) 
	        {
	                        System.out.println("Got error.  Returning null (404)");
	                        fault.printStackTrace();
	                        
	        }
		}
	   
	   
	   private void alert(String string) {
		// TODO Auto-generated method stub
		
	}



	public List<Patients> getPatient(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}



	public void postPatient(Patients pt) {
		// TODO Auto-generated method stub
		
	}


	public void deletePatient(Integer id) {
		// TODO Auto-generated method stub
		
	}


	public void updatePatient(Patients pt) {
		// TODO Auto-generated method stub
		
	}


	   

	



	

}
